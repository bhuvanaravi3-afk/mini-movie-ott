
# Mini Movie - Vertical OTT Platform

The ultimate destination for premium vertical short-form content.

## 🚀 How to Launch (Browser Only Method)

You don't need any coding software to put this app online. Follow these 3 steps:

### Part 1: GitHub (Hosting Your Files)
1. Sign in to [GitHub.com](https://github.com).
2. Click **New** (green button) to create a repository.
3. Name it (e.g., `my-series-app`).
4. On the setup screen, click the link: **"uploading an existing file"**.
5. Drag and drop all the files from this folder into your browser.
6. Click **Commit changes**.

### Part 2: Vercel (Creating the Website)
1. Sign in to [Vercel.com](https://vercel.com) using your GitHub account.
2. Click **Add New > Project**.
3. Import your `my-series-app` repository.
4. **Crucial Settings:**
   - **Framework Preset:** Choose `Vite`.
   - **Environment Variables:** Add `API_KEY` (Paste your Gemini API Key).
5. Click **Deploy**. Your site is now live at a `your-name.vercel.app` address!

### Part 3: GoDaddy Domain (Optional)
1. In Vercel, go to **Settings > Domains**.
2. Add your custom domain (e.g., `www.myseries.com`).
3. In GoDaddy DNS Settings:
   - **A Record**: Name `@` -> Value `76.76.21.21`
   - **CNAME Record**: Name `www` -> Value `cname.vercel-dns.com`

## ✨ Features
- **TikTok-Style UI**: Vertical-first playback optimized for mobile.
- **Nebula AI**: Smart episode recommendations and discovery.
- **Admin Dashboard**: Upload your own episodes directly in the browser.
