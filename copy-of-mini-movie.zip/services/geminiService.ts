
import { GoogleGenAI, Type } from "@google/genai";
import { Movie } from "../types";

// Initialize Gemini
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getAIRecommendations = async (query: string): Promise<Movie[]> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Generate a list of 12 creative, fictional short-form vertical video (mini-movie) episodes based on this user request: "${query}". 
      
      Constraints:
      1. They must be part of a 12-episode series structure.
      2. MAX DURATION is strictly 2 minutes (e.g., "1m", "2m").
      3. Make titles look like episodes (e.g., "The Beginning: Ep 1").
      4. Ensure the JSON is valid. 
      5. For images, do not generate URLs, just leave empty strings.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              title: { type: Type.STRING },
              description: { type: Type.STRING },
              matchScore: { type: Type.INTEGER },
              year: { type: Type.INTEGER },
              ageRating: { type: Type.STRING },
              duration: { type: Type.STRING },
              genre: { 
                type: Type.ARRAY,
                items: { type: Type.STRING }
              },
            },
            required: ["id", "title", "description", "matchScore", "year", "ageRating", "duration", "genre"]
          }
        }
      }
    });

    const rawData = response.text;
    if (!rawData) return [];

    const parsed = JSON.parse(rawData);
    
    // Hydrate with placeholder images
    return parsed.map((m: any, index: number) => ({
      ...m,
      thumbnailUrl: `https://picsum.photos/seed/${m.id || index + 'thumb'}/300/450`,
      backdropUrl: `https://picsum.photos/seed/${m.id || index + 'back'}/1280/720`,
      isOriginal: true
    }));

  } catch (error) {
    console.error("Gemini Recommendation Error:", error);
    return [];
  }
};
