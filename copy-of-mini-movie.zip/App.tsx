import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import ContentRow from './components/ContentRow';
import AISearch from './components/AISearch';
import VideoPlayer from './components/VideoPlayer';
import UserProfile from './components/UserProfile';
import UploadModal from './components/UploadModal';
import AuthModal from './components/AuthModal';
import { Movie, Category, ViewState, User } from './types';
import { FEATURED_MOVIE, INITIAL_CATEGORIES } from './constants';

const App: React.FC = () => {
  const [viewState, setViewState] = useState<ViewState>(ViewState.HOME);
  const [scrolled, setScrolled] = useState(false);
  
  // Modals
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);

  // User State
  const [user, setUser] = useState<User | null>(null);

  // Data State
  const [categories, setCategories] = useState<Category[]>(INITIAL_CATEGORIES);
  const [heroMovie, setHeroMovie] = useState<Movie>(FEATURED_MOVIE);

  // Check for persisted user session on load
  useEffect(() => {
    const storedUser = localStorage.getItem('mini_user');
    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser));
      } catch (e) {
        console.error("Failed to parse user");
      }
    }
  }, []);

  // Load persisted admin uploads from local storage
  useEffect(() => {
    const storedMovies = localStorage.getItem('admin_uploads');
    if (storedMovies) {
      try {
        const parsedMovies: Movie[] = JSON.parse(storedMovies);
        if (parsedMovies.length > 0) {
          // Create a special category for owner uploads
          const uploadsCategory: Category = {
            id: 'admin-uploads',
            title: '✨ New Releases (Admin)',
            movies: parsedMovies.reverse() // Newest first
          };
          
          setCategories(prev => {
            // Remove existing admin category if present to avoid duplicates
            const filtered = prev.filter(c => c.id !== 'admin-uploads');
            return [uploadsCategory, ...filtered];
          });
        }
      } catch (e) {
        console.error("Failed to parse stored movies", e);
      }
    }
  }, []);

  // Scroll listener for navbar
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Handlers

  const handleAuthSuccess = (newUser: User) => {
    setUser(newUser);
    localStorage.setItem('mini_user', JSON.stringify(newUser));
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('mini_user');
    setViewState(ViewState.HOME);
  };

  const handleMovieClick = (movie: Movie) => {
    // Browsing is free, but watching requires login
    if (!user) {
      setIsAuthOpen(true);
      return;
    }

    setHeroMovie(movie);
    setViewState(ViewState.PLAYER);
  };

  const handlePlayHero = () => {
    if (!user) {
      setIsAuthOpen(true);
      return;
    }
    setViewState(ViewState.PLAYER);
  };

  const handleNextMovie = () => {
    // Find current movie index within any category to determine the next one
    let found = false;
    let nextMovie: Movie | null = null;

    for (const category of categories) {
      const index = category.movies.findIndex(m => m.id === heroMovie.id);
      if (index !== -1) {
        // Found the current movie in this category
        if (index < category.movies.length - 1) {
          nextMovie = category.movies[index + 1];
        } else {
          // If it's the last one, loop back to the first
          nextMovie = category.movies[0];
        }
        found = true;
        break;
      }
    }
    
    // If not found in categories (e.g. it was the standalone featured hero), default to first trending
    if (!found || !nextMovie) {
       if (categories.length > 0 && categories[0].movies.length > 0) {
         nextMovie = categories[0].movies[0];
       }
    }

    if (nextMovie) {
      setHeroMovie(nextMovie);
    } else {
      setViewState(ViewState.HOME);
    }
  };

  const handleAIResults = (results: Movie[]) => {
    if (results.length > 0) {
      // Add the AI results as a new category at the TOP
      const newCategory: Category = {
        id: `ai-${Date.now()}`,
        title: "✨ AI Recommended For You",
        movies: results
      };
      setCategories(prev => [newCategory, ...prev]);
      setHeroMovie(results[0]);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleUploadClick = () => {
    if (!user) {
      setIsAuthOpen(true);
      return;
    }
    setIsUploadOpen(true);
  };

  const handleUploadComplete = (movie: Movie) => {
    // 1. Update State
    const uploadsCategory = categories.find(c => c.id === 'admin-uploads');
    if (uploadsCategory) {
       // Add to existing
       const updatedCategory = { ...uploadsCategory, movies: [movie, ...uploadsCategory.movies] };
       setCategories(prev => prev.map(c => c.id === 'admin-uploads' ? updatedCategory : c));
    } else {
       // Create new
       const newCategory: Category = {
        id: 'admin-uploads',
        title: '✨ New Releases (Admin)',
        movies: [movie]
       };
       setCategories(prev => [newCategory, ...prev]);
    }

    // 2. Persist to LocalStorage
    const storedMovies = localStorage.getItem('admin_uploads');
    let currentMovies: Movie[] = [];
    if (storedMovies) {
      try {
        currentMovies = JSON.parse(storedMovies);
      } catch (e) {}
    }
    const updatedMovies = [...currentMovies, movie];
    localStorage.setItem('admin_uploads', JSON.stringify(updatedMovies));

    // 3. Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleClosePlayer = () => {
    setViewState(ViewState.HOME);
  };

  return (
    <div className="min-h-screen bg-[#141414] text-white font-sans selection:bg-brand-accent selection:text-white">
      
      {viewState === ViewState.PLAYER && (
        <VideoPlayer 
          movie={heroMovie} 
          onBack={handleClosePlayer} 
          onNext={handleNextMovie}
        />
      )}

      <Navbar 
        onSearchClick={() => setIsSearchOpen(true)} 
        onLogoClick={() => {
           setCategories(INITIAL_CATEGORIES);
           setHeroMovie(FEATURED_MOVIE);
           window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onLoginClick={() => setIsAuthOpen(true)}
        onProfileClick={() => setIsProfileOpen(true)}
        onUploadClick={handleUploadClick}
        scrolled={scrolled}
        user={user}
      />

      <main className="relative z-0 pb-20">
        <Hero movie={heroMovie} onPlay={handlePlayHero} />
        
        <div className="relative z-10 -mt-24 md:-mt-48 lg:-mt-60 pl-4 md:pl-12 bg-gradient-to-t from-[#141414] via-[#141414]/80 to-transparent pb-8">
           {/* Spacer for visual overlap */}
        </div>

        <div className="space-y-8 md:space-y-12 relative z-20 bg-[#141414] pt-4">
          {categories.map((category) => (
            <ContentRow 
              key={category.id}
              id={category.id}
              title={category.title} 
              movies={category.movies} 
              onMovieClick={handleMovieClick}
              isGenerated={category.id.startsWith('ai-')}
            />
          ))}
        </div>

        <footer className="px-12 py-20 text-gray-500 text-sm text-center bg-[#141414]">
          <div className="max-w-4xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-8 mb-8 text-left">
            <div className="flex flex-col gap-2">
              <span className="hover:underline cursor-pointer">Audio Description</span>
              <span className="hover:underline cursor-pointer">Investor Relations</span>
              <span className="hover:underline cursor-pointer">Legal Notices</span>
            </div>
            <div className="flex flex-col gap-2">
              <span className="hover:underline cursor-pointer">Help Center</span>
              <span className="hover:underline cursor-pointer">Jobs</span>
              <span className="hover:underline cursor-pointer">Cookie Preferences</span>
            </div>
            <div className="flex flex-col gap-2">
              <span className="hover:underline cursor-pointer">Gift Cards</span>
              <span className="hover:underline cursor-pointer">Terms of Use</span>
              <span className="hover:underline cursor-pointer">Corporate Information</span>
            </div>
            <div className="flex flex-col gap-2">
              <span className="hover:underline cursor-pointer">Media Center</span>
              <span className="hover:underline cursor-pointer">Privacy</span>
              <span className="hover:underline cursor-pointer">Contact Us</span>
            </div>
          </div>
          <p>© 2024 Mini Movie, Inc. All Vertical Rights Reserved.</p>
        </footer>
      </main>

      <AISearch 
        isOpen={isSearchOpen} 
        onClose={() => setIsSearchOpen(false)} 
        onResults={handleAIResults} 
      />

      {/* Auth Modal replaces Subscription Modal */}
      <AuthModal 
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onAuthSuccess={handleAuthSuccess}
      />

      <UserProfile 
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        user={user}
        onLogout={handleLogout}
      />

      <UploadModal 
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        onUploadComplete={handleUploadComplete}
      />
    </div>
  );
};

export default App;