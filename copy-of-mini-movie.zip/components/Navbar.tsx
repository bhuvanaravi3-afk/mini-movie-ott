import React from 'react';
import { Search, Bell, User as UserIcon, Smartphone, ShieldAlert } from 'lucide-react';
import { User } from '../types';

interface NavbarProps {
  onSearchClick: () => void;
  onLogoClick: () => void;
  onLoginClick: () => void;
  onProfileClick: () => void;
  onUploadClick: () => void;
  scrolled: boolean;
  user: User | null;
}

const Navbar: React.FC<NavbarProps> = ({ 
  onSearchClick, 
  onLogoClick, 
  onLoginClick, 
  onProfileClick, 
  onUploadClick,
  scrolled, 
  user 
}) => {
  const scrollToTrending = () => {
    const element = document.getElementById('trending');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <nav 
      className={`fixed top-0 w-full z-50 transition-all duration-300 px-4 md:px-12 py-4 flex items-center justify-between ${
        scrolled ? 'bg-brand-dark/95 backdrop-blur-sm shadow-lg' : 'bg-gradient-to-b from-black/80 to-transparent'
      }`}
    >
      <div className="flex items-center gap-8">
        <div 
          className="flex items-center gap-2 text-2xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-brand-accent to-brand-purple cursor-pointer tracking-tighter"
          onClick={onLogoClick}
        >
          <Smartphone className="text-brand-accent" fill="currentColor" size={24} />
          MINI MOVIE
        </div>
        
        <div className="hidden md:flex items-center gap-6 text-sm font-medium text-gray-300">
          <button onClick={onLogoClick} className="hover:text-white transition">For You</button>
          <button onClick={scrollToTrending} className="hover:text-white transition">Trending Now</button>
          <button className="hover:text-white transition">Minis</button>
          <button className="hover:text-white transition">Series</button>
        </div>
      </div>

      <div className="flex items-center gap-6">
        {/* Admin/Upload Button - Only visible if logged in (demo purpose: accessible to all logged in) */}
        {user && (
          <button 
            onClick={onUploadClick}
            className="hidden md:flex items-center gap-2 text-gray-300 hover:text-white transition bg-white/10 px-3 py-1.5 rounded-full border border-white/5 hover:bg-white/20"
          >
            <ShieldAlert size={16} className="text-brand-accent" />
            <span className="text-xs font-bold uppercase tracking-wide">Admin</span>
          </button>
        )}

        <button 
          onClick={onSearchClick}
          className="flex items-center gap-2 text-gray-300 hover:text-white transition group"
        >
          <Search size={20} />
          <span className="hidden lg:inline opacity-0 group-hover:opacity-100 transition-opacity duration-300 text-sm">
            Find Minis
          </span>
        </button>
        <Bell size={20} className="text-gray-300 cursor-pointer hover:text-white transition hidden sm:block" />
        
        {user ? (
          <button 
            onClick={onProfileClick}
            className="flex items-center gap-2 cursor-pointer relative group"
          >
            <div className="w-8 h-8 rounded-full flex items-center justify-center border-2 transition-all bg-gradient-to-tr from-brand-accent to-brand-purple border-white/20">
              <span className="font-bold text-white text-xs">{user.name.substring(0, 2).toUpperCase()}</span>
            </div>
          </button>
        ) : (
          <button 
            onClick={onLoginClick}
            className="bg-white text-black hover:bg-gray-200 px-4 py-1.5 rounded-full text-sm font-bold transition shadow-lg"
          >
            Login
          </button>
        )}
      </div>
    </nav>
  );
};

export default Navbar;