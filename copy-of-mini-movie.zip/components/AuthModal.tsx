import React, { useState } from 'react';
import { X, Smartphone, ArrowRight, Loader2, CheckCircle2 } from 'lucide-react';
import { User } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAuthSuccess: (user: User) => void;
}

const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, onAuthSuccess }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Simulate API call
    setTimeout(() => {
      const fakeUser: User = {
        id: `user-${Date.now()}`,
        name: isLogin ? (email.split('@')[0] || 'User') : name,
        email: email
      };
      
      setIsLoading(false);
      onAuthSuccess(fakeUser);
      onClose();
      
      // Reset form
      setEmail('');
      setPassword('');
      setName('');
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
      <div className="relative w-full max-w-md bg-[#181818] rounded-2xl shadow-2xl border border-white/10 overflow-hidden flex flex-col">
        
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 hover:bg-white/10 rounded-full transition text-gray-400 hover:text-white"
        >
          <X size={20} />
        </button>

        <div className="p-8 flex flex-col items-center">
          <div className="mb-6 bg-gradient-to-br from-brand-accent to-brand-purple p-4 rounded-2xl shadow-lg shadow-brand-purple/20">
            <Smartphone size={32} className="text-white" />
          </div>

          <h2 className="text-2xl font-bold text-white mb-2">
            {isLogin ? 'Welcome Back' : 'Create Account'}
          </h2>
          <p className="text-gray-400 text-center mb-8 text-sm">
            {isLogin ? 'Login to continue watching your favorite minis.' : 'Sign up for free unlimited access to all content.'}
          </p>

          <form onSubmit={handleSubmit} className="w-full space-y-4">
            {!isLogin && (
              <div className="space-y-1">
                <label className="text-xs font-bold text-gray-400 uppercase ml-1">Full Name</label>
                <input 
                  type="text" 
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-gray-600 focus:border-brand-accent focus:outline-none transition"
                  placeholder="John Doe"
                />
              </div>
            )}

            <div className="space-y-1">
              <label className="text-xs font-bold text-gray-400 uppercase ml-1">Email Address</label>
              <input 
                type="email" 
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-gray-600 focus:border-brand-accent focus:outline-none transition"
                placeholder="name@example.com"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-gray-400 uppercase ml-1">Password</label>
              <input 
                type="password" 
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-gray-600 focus:border-brand-accent focus:outline-none transition"
                placeholder="••••••••"
              />
            </div>

            <button 
              type="submit"
              disabled={isLoading}
              className="w-full bg-brand-accent hover:bg-red-600 text-white font-bold py-3 rounded-xl transition transform active:scale-95 shadow-lg shadow-brand-accent/20 flex items-center justify-center gap-2 mt-4"
            >
              {isLoading ? (
                <Loader2 className="animate-spin" size={20} />
              ) : (
                <>
                  {isLogin ? 'Login' : 'Sign Up Free'} <ArrowRight size={18} />
                </>
              )}
            </button>
          </form>

          <div className="mt-6 pt-6 border-t border-white/5 w-full text-center">
            <p className="text-gray-400 text-sm">
              {isLogin ? "Don't have an account? " : "Already have an account? "}
              <button 
                onClick={() => setIsLogin(!isLogin)}
                className="text-brand-accent font-bold hover:underline"
              >
                {isLogin ? 'Sign Up' : 'Login'}
              </button>
            </p>
          </div>
        </div>
        
        <div className="bg-brand-purple/10 p-3 text-center border-t border-white/5">
           <p className="text-[10px] text-brand-purple font-medium flex items-center justify-center gap-1">
             <CheckCircle2 size={12} /> 100% Free Forever. No Credit Card Required.
           </p>
        </div>
      </div>
    </div>
  );
};

export default AuthModal;