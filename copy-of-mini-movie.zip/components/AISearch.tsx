import React, { useState } from 'react';
import { X, Sparkles, Loader2 } from 'lucide-react';
import { getAIRecommendations } from '../services/geminiService';
import { Movie } from '../types';

interface AISearchProps {
  isOpen: boolean;
  onClose: () => void;
  onResults: (results: Movie[]) => void;
}

const AISearch: React.FC<AISearchProps> = ({ isOpen, onClose, onResults }) => {
  const [query, setQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setIsLoading(true);
    try {
      const recommendations = await getAIRecommendations(query);
      onResults(recommendations);
      onClose();
    } catch (error) {
      console.error("Failed to fetch recommendations");
    } finally {
      setIsLoading(false);
      setQuery('');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
      <div className="relative w-full max-w-3xl bg-[#181818] rounded-xl shadow-2xl border border-white/10 overflow-hidden">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 p-2 hover:bg-white/10 rounded-full transition"
        >
          <X className="text-gray-400 hover:text-white" />
        </button>

        <div className="p-8 md:p-12 flex flex-col items-center text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-brand-purple to-blue-500 rounded-full flex items-center justify-center mb-6 shadow-lg shadow-brand-purple/30">
            <Sparkles className="text-white w-8 h-8" />
          </div>

          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Ask Nebula AI
          </h2>
          <p className="text-gray-400 mb-8 max-w-lg">
            Describe what you're in the mood for. I can find specific genres, themes, or even generate a custom list based on your feelings.
          </p>

          <form onSubmit={handleSearch} className="w-full relative">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="e.g., 'Sci-fi movies about artificial intelligence featuring robots' or 'Something sad and rainy'"
              className="w-full bg-black/40 border border-white/20 rounded-full py-4 px-6 text-white placeholder-gray-500 focus:outline-none focus:border-brand-purple transition text-lg"
              autoFocus
            />
            <button 
              type="submit"
              disabled={isLoading || !query}
              className="absolute right-2 top-2 bottom-2 bg-white text-black px-6 rounded-full font-bold hover:bg-gray-200 transition disabled:opacity-50 flex items-center gap-2"
            >
              {isLoading ? <Loader2 className="animate-spin" size={20} /> : 'Ask'}
            </button>
          </form>
          
          <div className="mt-8 flex flex-wrap gap-3 justify-center">
            {['Travel Documentaries', '90s Action', 'Feel-good Comedies', 'Cyberpunk Anime'].map((tag) => (
              <button 
                key={tag}
                onClick={() => setQuery(tag)}
                className="px-4 py-2 rounded-full bg-white/5 border border-white/10 text-sm text-gray-300 hover:bg-white/10 hover:border-white/30 transition"
              >
                {tag}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AISearch;
