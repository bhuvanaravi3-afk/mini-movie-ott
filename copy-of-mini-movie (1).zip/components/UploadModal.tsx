
import React, { useState, useRef } from 'react';
import { X, Upload, FileVideo, CheckCircle2, Loader2, Link as LinkIcon, Image as ImageIcon, Globe, Key, Copy, Check, MousePointer2, Smartphone, Monitor, ChevronRight, Settings2, FolderUp, FileCode, FolderClosed } from 'lucide-react';
import { Movie } from '../types';

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUploadComplete: (movie: Movie) => void;
}

const UploadModal: React.FC<UploadModalProps> = ({ isOpen, onClose, onUploadComplete }) => {
  const [mode, setMode] = useState<'file' | 'url' | 'deploy'>('file');
  
  // File Mode State
  const [isDragging, setIsDragging] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  
  // URL Mode State
  const [externalThumbnail, setExternalThumbnail] = useState('');
  const [externalVideo, setExternalVideo] = useState('');
  
  // Common Form State
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [genre, setGenre] = useState('Drama');

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleUpload = () => {
    if (!title) return;
    setUploading(true);
    const finalizeUpload = (thumb: string, vid?: string) => {
         const newMovie: Movie = {
          id: `admin-upload-${Date.now()}`,
          title: title,
          description: description || "No description provided.",
          thumbnailUrl: thumb,
          backdropUrl: thumb,
          videoUrl: vid,
          matchScore: 98,
          year: new Date().getFullYear(),
          ageRating: "13+",
          duration: "2m",
          genre: [genre, "Admin Upload"],
          isOriginal: true
        };
        setUploading(false);
        onUploadComplete(newMovie);
        onClose();
    };
    
    if (mode === 'file') {
        let currentProgress = 0;
        const interval = setInterval(() => {
          currentProgress += Math.random() * 15;
          if (currentProgress >= 100) {
            currentProgress = 100;
            clearInterval(interval);
            const thumb = previewUrl || `https://picsum.photos/seed/${Date.now()}/300/450`;
            finalizeUpload(thumb);
          } else { setProgress(currentProgress); }
        }, 200);
    } else {
        setTimeout(() => { finalizeUpload(externalThumbnail || `https://picsum.photos/seed/${Date.now()}/300/450`, externalVideo); }, 1000);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black/95 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in">
      <div className="relative w-full max-w-4xl bg-[#181818] rounded-3xl shadow-2xl border border-white/10 overflow-hidden flex flex-col max-h-[90vh]">
        
        <div className="flex items-center justify-between p-6 border-b border-white/5 bg-[#202020]">
          <h2 className="text-xl font-bold text-white flex items-center gap-3">
            <div className="bg-brand-accent p-2 rounded-xl shadow-lg shadow-brand-accent/20">
               <Smartphone className="text-white" size={20} />
            </div>
            Mini Movie: Launch Assistant
          </h2>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition text-gray-400 hover:text-white">
            <X size={20} />
          </button>
        </div>

        {/* Mode Switcher */}
        <div className="flex bg-[#121212] p-2 m-4 rounded-2xl border border-white/5">
            <button onClick={() => setMode('file')} className={`flex-1 py-3 text-sm font-bold rounded-xl transition flex items-center justify-center gap-2 ${mode === 'file' ? 'bg-white/10 text-white shadow-lg' : 'text-gray-500 hover:text-gray-300'}`}>
                <FileVideo size={16} /> Manage Content
            </button>
            <button onClick={() => setMode('deploy')} className={`flex-1 py-3 text-sm font-bold rounded-xl transition flex items-center justify-center gap-2 ${mode === 'deploy' ? 'bg-white/10 text-white shadow-lg' : 'text-gray-500 hover:text-gray-300'}`}>
                <Globe size={16} /> Launch Platform
            </button>
        </div>

        <div className="flex-1 overflow-y-auto no-scrollbar px-6 pb-8">
          {mode === 'deploy' ? (
            <div className="space-y-6 animate-fade-in">
              
              {/* Step 0: Checklist */}
              <div className="bg-[#202020] rounded-2xl p-6 border border-white/5 border-l-4 border-yellow-500">
                <div className="flex gap-5">
                  <div className="w-12 h-12 rounded-2xl bg-yellow-500 flex items-center justify-center shrink-0">
                    <FileCode className="text-white" size={24} />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-white mb-2">Checklist: Do you have these files?</h3>
                    <p className="text-sm text-gray-400 mb-4">Ensure your project folder has these files before downloading or uploading:</p>
                    
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                       {['index.html', 'package.json', 'vite.config.ts', 'App.tsx', 'index.tsx', 'types.ts', 'constants.ts', 'README.md'].map(file => (
                         <div key={file} className="flex items-center gap-2 bg-black/30 px-3 py-2 rounded-lg border border-white/5 text-[11px] text-gray-300">
                           <CheckCircle2 size={12} className="text-green-500" /> {file}
                         </div>
                       ))}
                       <div className="flex items-center gap-2 bg-black/30 px-3 py-2 rounded-lg border border-white/5 text-[11px] text-blue-400 font-bold">
                           <FolderClosed size={12} /> components/
                       </div>
                       <div className="flex items-center gap-2 bg-black/30 px-3 py-2 rounded-lg border border-white/5 text-[11px] text-blue-400 font-bold">
                           <FolderClosed size={12} /> services/
                       </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Step 1: GitHub */}
              <div className="bg-[#202020] rounded-2xl p-6 border border-white/5 border-l-4 border-blue-500">
                <div className="flex gap-5">
                  <div className="w-12 h-12 rounded-2xl bg-blue-500 flex items-center justify-center shrink-0">
                    <FolderUp className="text-white" size={24} />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-white mb-2">Step 1: Upload to GitHub</h3>
                    <div className="space-y-4">
                      <div className="bg-black/40 p-4 rounded-xl border border-white/10">
                         <p className="text-xs text-gray-300 mb-2 font-bold">On your new GitHub repo page, click:</p>
                         <div className="bg-[#2d333b] p-3 rounded-lg border border-white/5 text-[11px] text-gray-400 font-mono">
                           …or <span className="text-blue-400 font-bold underline cursor-default">uploading an existing file</span>
                         </div>
                      </div>
                      <p className="text-sm text-gray-300">Drag <b>everything</b> from your folder into the GitHub browser window.</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Step 2: Vercel */}
              <div className="bg-[#202020] rounded-2xl p-6 border border-white/5 border-l-4 border-brand-accent">
                <div className="flex gap-5">
                  <div className="w-12 h-12 rounded-2xl bg-brand-accent flex items-center justify-center shrink-0">
                    <Settings2 className="text-white" size={24} />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-bold text-white mb-2">Step 2: Connect Vercel</h3>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 bg-black/30 rounded-xl border border-white/5">
                        <span className="text-[10px] text-gray-500 font-black uppercase">Framework Preset</span>
                        <span className="text-brand-accent font-black tracking-widest bg-brand-accent/10 px-2 py-0.5 rounded">VITE</span>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-black/30 rounded-xl border border-white/5">
                        <span className="text-[10px] text-gray-500 font-black uppercase">Environment Variable</span>
                        <span className="text-white font-mono text-xs">API_KEY = (Paste Your Key)</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          ) : (
            <div className="flex flex-col md:flex-row gap-8 pt-4">
              <div className="w-full md:w-1/2">
                <div 
                  className={`h-72 border-2 border-dashed rounded-3xl flex flex-col items-center justify-center p-8 text-center transition-all relative overflow-hidden ${isDragging ? 'border-brand-accent bg-brand-accent/5' : 'border-white/10 hover:border-white/30 bg-white/5'}`}
                  onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
                  onDragLeave={() => setIsDragging(false)}
                  onDrop={(e) => { e.preventDefault(); setIsDragging(false); const f = e.dataTransfer.files[0]; if(f) { setFile(f); setPreviewUrl(URL.createObjectURL(f)); } }}
                >
                   {previewUrl ? (
                      <video src={previewUrl} className="w-full h-full object-cover rounded-2xl" muted autoPlay loop />
                   ) : (
                      <>
                        <div className="w-16 h-16 bg-white/5 rounded-2xl flex items-center justify-center mb-4">
                          <Upload className="text-gray-400" size={32} />
                        </div>
                        <p className="text-white font-bold mb-2">Drop your video here</p>
                        <p className="text-xs text-gray-500 mb-6">Vertical videos (9:16) look best!</p>
                        <button onClick={() => fileInputRef.current?.click()} className="px-6 py-2 bg-white/10 rounded-full text-xs font-bold text-white hover:bg-white/20 transition">Select File</button>
                      </>
                   )}
                   <input type="file" ref={fileInputRef} className="hidden" accept="video/*" onChange={e => { const f = e.target.files?.[0]; if(f) { setFile(f); setPreviewUrl(URL.createObjectURL(f)); } }} />
                   
                   {uploading && (
                      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm flex flex-col items-center justify-center rounded-3xl z-30">
                        <Loader2 className="animate-spin text-brand-accent mb-3" size={40} />
                        <span className="text-sm font-bold text-white">{Math.round(progress)}% Complete</span>
                      </div>
                   )}
                </div>
              </div>

              <div className="w-full md:w-1/2 space-y-5">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Video Title</label>
                  <input type="text" placeholder="e.g. Midnight Mystery Ep.1" value={title} onChange={e => setTitle(e.target.value)} className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-3.5 text-white focus:border-brand-accent outline-none transition" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Story Brief</label>
                  <textarea placeholder="Describe the tension and drama..." value={description} onChange={e => setDescription(e.target.value)} rows={3} className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-3.5 text-white focus:border-brand-accent outline-none transition resize-none" />
                </div>
                <button onClick={handleUpload} disabled={!title || uploading || (!file && mode === 'file')} className="w-full bg-brand-accent py-4 rounded-2xl font-black text-white hover:bg-red-600 transition shadow-xl shadow-brand-accent/20 flex items-center justify-center gap-2 group">
                   {uploading ? 'Finalizing...' : (
                     <>
                        Post to Platform <ChevronRight size={18} className="group-hover:translate-x-1 transition" />
                     </>
                   )}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default UploadModal;
