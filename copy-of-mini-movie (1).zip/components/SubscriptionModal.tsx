import React, { useState } from 'react';
import { X, Lock, Gem, Bell, Star, Plus, Check, Loader2, PlayCircle, Monitor, QrCode, Copy, ArrowLeft, Smartphone } from 'lucide-react';

// Custom Payment Icons
const PhonePeIcon = () => (
  <svg viewBox="0 0 24 24" className="w-full h-full" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="12" cy="12" r="12" fill="#5f259f"/>
    <path d="M15.5 7.5H11.5C9.84315 7.5 8.5 8.84315 8.5 10.5V16.5H10.5V12.5H11.5C12.6046 12.5 13.5 11.6046 13.5 10.5V9.5C13.5 8.39543 12.6046 7.5 11.5 7.5Z" fill="white"/>
    <path d="M13 13.5H15.5C16.6046 13.5 17.5 14.3954 17.5 15.5V16.5H15.5V15.5H13V13.5Z" fill="#ff9e00"/>
  </svg>
);

const GPayIcon = () => (
  <svg viewBox="0 0 24 24" className="w-full h-full" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="12" cy="12" r="12" fill="white"/>
    <path d="M10.5 12.4H15.3C15.1 13.6 14.1 15.5 12.2 15.5C10.5 15.5 9.1 14.1 9.1 12.4C9.1 10.7 10.5 9.3 12.2 9.3C13.1 9.3 13.8 9.7 14.1 10L15.7 8.4C14.8 7.5 13.6 7 12.2 7C9.2 7 6.8 9.4 6.8 12.4C6.8 15.4 9.2 17.8 12.2 17.8C15.3 17.8 17.4 15.6 17.4 12.5C17.4 12.1 17.4 11.8 17.3 11.5H12.2L10.5 12.4Z" fill="#4285F4"/>
    <path d="M15.7 8.4L14.1 10C13.8 9.7 13.1 9.3 12.2 9.3C10.5 9.3 9.1 10.7 9.1 12.4C9.1 12.5 9.1 12.6 9.1 12.7L8.5 14.5L6.8 12.4C6.8 9.4 9.2 7 12.2 7C13.6 7 14.8 7.5 15.7 8.4Z" fill="#EA4335"/>
    <path d="M12.2 17.8C10.4 17.8 8.8 17.0 7.7 15.7L8.5 14.5L9.1 12.7C9.5 14.3 10.7 15.5 12.2 15.5C14.1 15.5 15.1 13.6 15.3 12.4H16.3L17.2 12.6C16.9 15.6 14.8 17.8 12.2 17.8Z" fill="#34A853"/>
    <path d="M17.3 11.5H17.2L16.3 12.4H15.3C15.4 11.8 15.4 11.2 15.4 10.6V10.5H17.4C17.4 10.8 17.4 11.1 17.3 11.5Z" fill="#FBBC05"/>
  </svg>
);

const PaytmIcon = () => (
  <svg viewBox="0 0 24 24" className="w-full h-full" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="12" cy="12" r="12" fill="#ffffff"/>
    <path d="M6 9H9.5C10.5 9 11 9.5 11 10.5V15H9V11H7.5V15H6V9Z" fill="#002E6E"/>
    <path d="M13 9H17V10.5H15V15H13V9Z" fill="#00B9F1"/>
  </svg>
);

interface SubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubscribe: () => void;
}

const SubscriptionModal: React.FC<SubscriptionModalProps> = ({ isOpen, onClose, onSubscribe }) => {
  const [step, setStep] = useState<'details' | 'payment'>('details');
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const ACCOUNT_DETAILS = {
    upiId: "9789435555@ybl",
    name: "Bala",
    bankName: "Bank Of Baroda - 2985",
    number: "+91 9789435555",
    amount: "₹1.00"
  };

  // Generate dynamic UPI QR code URL
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=upi://pay?pa=${ACCOUNT_DETAILS.upiId}&pn=${ACCOUNT_DETAILS.name}&am=1&cu=INR`;

  if (!isOpen) return null;

  const handleStartPayment = () => {
    setStep('payment');
  };

  const handleConfirmPayment = () => {
    setIsLoading(true);
    // Simulate verification delay
    setTimeout(() => {
      setIsLoading(false);
      onSubscribe();
      setStep('details'); // Reset for next time
    }, 2000);
  };

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(ACCOUNT_DETAILS.upiId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleBack = () => {
    setStep('details');
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-md flex items-center justify-center p-4 animate-fade-in overflow-hidden">
      <div className="relative w-full max-w-[420px] h-full max-h-[90vh] bg-[#0f0f0f] rounded-[2rem] shadow-2xl border border-white/10 flex flex-col overflow-hidden">
        
        {/* Close Button */}
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 z-30 p-2 bg-black/40 hover:bg-black/60 rounded-full transition text-white"
        >
          <X size={20} />
        </button>

        {/* Header (Only for Payment Step) */}
        {step === 'payment' && (
            <div className="absolute top-0 left-0 w-full p-4 z-20 flex items-center bg-[#0f0f0f]/90 backdrop-blur-sm border-b border-white/5">
                <button onClick={handleBack} className="p-2 hover:bg-white/10 rounded-full text-white transition mr-2">
                    <ArrowLeft size={20} />
                </button>
                <span className="font-bold text-white">Confirm Payment</span>
            </div>
        )}

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto no-scrollbar relative">
            
            {step === 'details' ? (
                <>
                    {/* Top Section with Image */}
                    <div className="relative h-64 w-full bg-[#141414]">
                    <img 
                        src="https://picsum.photos/seed/drama/800/600" 
                        alt="Premium Content" 
                        className="w-full h-full object-cover opacity-90"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#0f0f0f] via-transparent to-transparent"></div>
                    
                    <div className="absolute top-8 left-6">
                        <div className="relative">
                            {/* Comic style pop animation */}
                            <div className="absolute -top-4 -left-4 w-12 h-12 border-2 border-dashed border-yellow-400 rounded-full animate-spin-slow opacity-50"></div>
                        </div>
                    </div>

                    <div className="absolute bottom-6 left-0 w-full px-6 flex justify-center">
                        <div className="bg-white/20 backdrop-blur-md rounded-full px-4 py-2 border border-white/20 text-xs text-white text-center font-medium shadow-lg">
                            Start trial ka button dabao, aur maza uthao! 🔊
                        </div>
                    </div>
                    </div>

                    {/* Content Section */}
                    <div className="px-6 pb-32 pt-2 bg-[#0f0f0f] relative z-10">
                    
                        <div className="text-center mb-8">
                            <h2 className="text-2xl font-bold text-[#FFE5B4] mb-2">Enjoy Mini Movie For Free</h2>
                            <div className="flex items-center justify-center gap-2 text-sm text-gray-400">
                                <span>10,000+ Episodes</span>
                                <span>•</span>
                                <span className="flex items-center gap-1 text-white font-semibold">Rated 4.7 <Star size={12} fill="#FFE5B4" className="text-[#FFE5B4]"/></span>
                            </div>
                        </div>

                        {/* Benefits Divider */}
                        <div className="flex items-center gap-4 mb-6">
                            <div className="h-[1px] bg-gradient-to-r from-transparent to-gray-700 flex-1"></div>
                            <span className="text-[#FFE5B4] text-xs font-bold tracking-widest uppercase">Your Benefits</span>
                            <div className="h-[1px] bg-gradient-to-l from-transparent to-gray-700 flex-1"></div>
                        </div>

                        {/* Benefits Grid */}
                        <div className="grid grid-cols-2 gap-4 mb-8">
                            <div className="flex flex-col items-center text-center p-2">
                                <div className="w-12 h-12 rounded-2xl border border-[#FFE5B4]/30 bg-[#1a1a1a] flex items-center justify-center mb-3 shadow-[0_0_10px_rgba(255,229,180,0.1)]">
                                    <PlayCircle className="text-[#FFE5B4]" size={24} />
                                </div>
                                <h3 className="text-white font-bold text-sm mb-1">Unlimited Viewing</h3>
                                <p className="text-xs text-gray-500 leading-tight">10,000+ desi episodes and new shows weekly.</p>
                            </div>
                            <div className="flex flex-col items-center text-center p-2">
                                <div className="w-12 h-12 rounded-2xl border border-[#FFE5B4]/30 bg-[#1a1a1a] flex items-center justify-center mb-3 shadow-[0_0_10px_rgba(255,229,180,0.1)]">
                                    <Monitor className="text-[#FFE5B4]" size={24} />
                                </div>
                                <h3 className="text-white font-bold text-sm mb-1">Full HD Quality</h3>
                                <p className="text-xs text-gray-500 leading-tight">Watch in crystal-clear Full HD resolution.</p>
                            </div>
                        </div>

                        {/* Testimonials Divider */}
                        <div className="flex items-center gap-4 mb-6">
                            <div className="h-[1px] bg-gradient-to-r from-transparent to-gray-700 flex-1"></div>
                            <span className="text-[#FFE5B4] text-xs font-bold tracking-widest uppercase">What Users Say</span>
                            <div className="h-[1px] bg-gradient-to-l from-transparent to-gray-700 flex-1"></div>
                        </div>

                        {/* Testimonial Card */}
                        <div className="bg-[#1a1a1a] rounded-xl p-5 border border-white/5 mb-8 shadow-lg">
                            <p className="text-gray-300 text-sm italic leading-relaxed mb-4">
                                "Finally, a great app for desi stories. The HD quality is amazing, and it works perfectly on my phone. Finally, a good app for drama that is fully paisa vasool."
                            </p>
                            <div className="flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                    <img src="https://randomuser.me/api/portraits/women/44.jpg" alt="User" className="w-8 h-8 rounded-full border border-gray-600" />
                                    <div>
                                        <p className="text-white text-xs font-bold">Priya S</p>
                                        <p className="text-[10px] text-gray-500">Ahmedabad</p>
                                    </div>
                                </div>
                                <div className="flex gap-0.5">
                                    {[1,2,3,4,5].map(i => <Star key={i} size={12} fill="white" className="text-white"/>)}
                                </div>
                            </div>
                        </div>

                        {/* Vertical Timeline Plan */}
                        <div className="bg-[#1a1a1a] rounded-2xl p-6 relative overflow-hidden border border-white/5 mb-4">
                            {/* Vertical Line */}
                            <div className="absolute left-[43px] top-10 bottom-10 w-0.5 bg-[#FFE5B4]/30"></div>

                            <div className="space-y-8 relative z-10">
                                {/* Step 1 */}
                                <div className="flex gap-4">
                                    <div className="w-10 h-10 rounded-xl bg-[#FFE5B4] flex items-center justify-center shrink-0 shadow-[0_0_15px_rgba(255,229,180,0.3)] z-10">
                                    <Lock size={18} className="text-black font-bold" />
                                    </div>
                                    <div>
                                    <h3 className="font-bold text-white text-sm md:text-base">Start your free trial</h3>
                                    <p className="text-gray-400 text-xs mt-0.5">Pay ₹1, get it back instantly</p>
                                    </div>
                                </div>

                                {/* Step 2 */}
                                <div className="flex gap-4">
                                    <div className="w-10 h-10 rounded-xl bg-[#FFE5B4] flex items-center justify-center shrink-0 shadow-[0_0_15px_rgba(255,229,180,0.3)] z-10">
                                    <Gem size={18} className="text-black" />
                                    </div>
                                    <div>
                                    <h3 className="font-bold text-white text-sm md:text-base">Enjoy unlimited series</h3>
                                    <p className="text-gray-400 text-xs mt-0.5">Watch ad-free. Cancel anytime.</p>
                                    </div>
                                </div>

                                {/* Step 3 */}
                                <div className="flex gap-4">
                                    <div className="w-10 h-10 rounded-xl bg-[#FFE5B4] flex items-center justify-center shrink-0 shadow-[0_0_15px_rgba(255,229,180,0.3)] z-10">
                                    <Bell size={18} className="text-black" />
                                    </div>
                                    <div>
                                    <h3 className="font-bold text-white text-sm md:text-base">Notified before autopay</h3>
                                    <p className="text-gray-400 text-xs mt-0.5">₹599/3 months autopay after 1 day</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </>
            ) : (
                /* Payment Step Content */
                <div className="pt-20 px-6 pb-32 h-full flex flex-col items-center">
                    <div className="w-full bg-[#1a1a1a] rounded-2xl p-6 border border-white/10 text-center mb-6">
                         <h3 className="text-gray-400 text-sm mb-2">Total Amount</h3>
                         <h1 className="text-4xl font-bold text-white mb-1">{ACCOUNT_DETAILS.amount}</h1>
                         <p className="text-xs text-[#FFE5B4] bg-[#FFE5B4]/10 py-1 px-3 rounded-full inline-block mt-2">Trial Refundable</p>
                    </div>

                    <div className="w-full bg-white p-6 rounded-2xl mb-6 flex flex-col items-center relative">
                         {/* Generated QR Code */}
                         <div className="w-48 h-48 bg-gray-100 rounded-lg flex items-center justify-center mb-4 relative overflow-hidden border-2 border-gray-200">
                             <img src={qrCodeUrl} alt="Payment QR Code" className="w-full h-full object-contain" />
                             {/* Center Icon Overlay */}
                             <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                                <div className="w-10 h-10 bg-white rounded-full p-1 shadow-md">
                                    <PhonePeIcon />
                                </div>
                             </div>
                         </div>
                         
                         <p className="text-black font-bold text-lg mb-0">{ACCOUNT_DETAILS.name}</p>
                         <p className="text-gray-500 text-xs mb-2">{ACCOUNT_DETAILS.bankName}</p>
                         <p className="text-gray-500 text-xs mb-3">{ACCOUNT_DETAILS.number}</p>

                         <div className="flex items-center gap-2 bg-gray-100 py-2 px-4 rounded-lg mt-1 w-full justify-between">
                            <span className="text-sm text-gray-600 font-mono">{ACCOUNT_DETAILS.upiId}</span>
                            <button onClick={handleCopyUpi} className="text-blue-600">
                                {copied ? <Check size={16} /> : <Copy size={16} />}
                            </button>
                         </div>
                    </div>

                    <div className="w-full space-y-3">
                        <p className="text-center text-gray-400 text-xs">Accepted Payment Methods</p>
                        <div className="flex justify-center gap-4 opacity-80">
                             <div className="w-10 h-10 bg-white/10 rounded-full p-2"><PhonePeIcon /></div>
                             <div className="w-10 h-10 bg-white/10 rounded-full p-2"><GPayIcon /></div>
                             <div className="w-10 h-10 bg-white/10 rounded-full p-2"><PaytmIcon /></div>
                        </div>
                    </div>
                </div>
            )}
        </div>

        {/* Sticky Bottom Footer */}
        <div className="absolute bottom-0 left-0 w-full bg-[#0f0f0f] border-t border-white/5 p-5 pb-6 z-20 shadow-[0_-10px_40px_rgba(0,0,0,0.8)]">
            {step === 'details' ? (
                <>
                    <div className="text-center mb-3">
                    <p className="text-xs text-[#FFE5B4]">Join 7.4 Lakh+ users watching Mini Movie daily.</p>
                    </div>

                    {/* Payment Icons */}
                    <div className="flex justify-center gap-4 mb-4 opacity-70 scale-90">
                        <div className="w-8 h-8 rounded-full bg-white/5 border border-white/10 p-1 relative">
                            <PhonePeIcon />
                            <div className="absolute -top-1 -right-1 bg-[#FFE5B4] rounded-full p-0.5">
                                <Check size={6} className="text-black" />
                            </div>
                        </div>
                        <div className="w-8 h-8 rounded-full bg-white/5 border border-white/10 p-1">
                            <GPayIcon />
                        </div>
                        <div className="w-8 h-8 rounded-full bg-white/5 border border-white/10 p-1">
                            <PaytmIcon />
                        </div>
                        <div className="w-8 h-8 rounded-full bg-white/5 border border-white/10 flex items-center justify-center">
                            <Plus size={14} className="text-gray-400" />
                        </div>
                    </div>

                    <button
                        onClick={handleStartPayment}
                        className="w-full bg-gradient-to-r from-[#FFE5B4] to-[#F3C676] text-black py-4 rounded-xl font-bold text-lg hover:scale-[1.02] transition transform shadow-[0_4px_20px_rgba(255,229,180,0.2)] flex items-center justify-center gap-2"
                    >
                        Start FREE Trial for ₹1
                    </button>
                    <p className="text-center text-[10px] text-gray-500 mt-2">
                        We'll remind you. Cancel anytime.
                    </p>
                </>
            ) : (
                <>
                     <button
                        onClick={handleConfirmPayment}
                        disabled={isLoading}
                        className="w-full bg-green-500 text-white py-4 rounded-xl font-bold text-lg hover:bg-green-600 transition transform shadow-[0_4px_20px_rgba(34,197,94,0.2)] flex items-center justify-center gap-2 disabled:opacity-80"
                    >
                        {isLoading ? (
                        <>
                            <Loader2 className="animate-spin" size={20} /> Verifying...
                        </>
                        ) : (
                        <>
                            <Check size={20} /> I have Paid {ACCOUNT_DETAILS.amount}
                        </>
                        )}
                    </button>
                    <p className="text-center text-[10px] text-gray-500 mt-2">
                        Payments are verified securely within 24 hours if automated check fails.
                    </p>
                </>
            )}
        </div>
      </div>
    </div>
  );
};

export default SubscriptionModal;