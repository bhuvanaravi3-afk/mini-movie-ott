# Mini Movie - Vertical OTT Platform

The ultimate destination for premium vertical short-form content.

## 🚀 Deployment Guide (Vercel)

### Part 1: GitHub
1. Create a new repository on GitHub (e.g., `my-ott-app`).
2. Upload **all** files from this project folder into that repository.
3. Commit and push the changes.

### Part 2: Vercel Hosting
1. Login to [Vercel](https://vercel.com) using your GitHub account.
2. Click **"Add New"** > **"Project"**.
3. Select your repository.
4. **Framework Preset**: Ensure it says "Vite".
5. **Environment Variables**: 
   - Add a variable named `API_KEY`.
   - Paste your Gemini API Key as the value.
6. Click **Deploy**. Vercel will provide a URL like `https://your-project.vercel.app`.

---

## 🛍️ Integrating with Shopify

Once your app is live on Vercel:

1.  **Shopify Admin** -> **Online Store** -> **Pages**.
2.  Click **Add Page**.
3.  Title it "Watch Movies".
4.  Click the **Show HTML** button (`<>`) in the content box.
5.  Paste this code:

```html
<div style="position: relative; width: 100%; height: 95vh; overflow: hidden; border-radius: 8px; background: #000;">
  <iframe 
    src="https://YOUR-VERCEL-URL.vercel.app" 
    style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; border: none;"
    allow="autoplay; fullscreen; microphone; camera"
  ></iframe>
</div>
```

6.  **Save** and add the page to your store's **Navigation** menu.

---

## ✨ Features
- **Vertical Player**: Optimized for mobile-first scrolling.
- **Nebula AI**: Instant recommendations based on your mood.
- **Admin Tools**: Upload and manage your own series locally.