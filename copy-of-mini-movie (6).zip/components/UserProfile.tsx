import React from 'react';
import { X, User as UserIcon, Settings, LogOut, ChevronRight } from 'lucide-react';
import { User } from '../types';

interface UserProfileProps {
  isOpen: boolean;
  onClose: () => void;
  user: User | null;
  onLogout: () => void;
}

const UserProfile: React.FC<UserProfileProps> = ({ isOpen, onClose, user, onLogout }) => {
  if (!isOpen || !user) return null;

  return (
    <div className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
      <div className="relative w-full max-w-md bg-[#181818] rounded-2xl shadow-2xl border border-white/10 overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-white/5">
          <h2 className="text-xl font-bold text-white">My Profile</h2>
          <button 
            onClick={onClose}
            className="p-2 hover:bg-white/10 rounded-full transition text-gray-400 hover:text-white"
          >
            <X size={20} />
          </button>
        </div>

        {/* User Info */}
        <div className="p-6 flex items-center gap-4 bg-[#202020]">
          <div className="w-16 h-16 rounded-full flex items-center justify-center text-2xl shadow-lg bg-gradient-to-tr from-brand-accent to-brand-purple border border-white/20">
             <span className="font-bold text-white">{user.name.substring(0, 2).toUpperCase()}</span>
          </div>
          <div>
            <h3 className="text-lg font-bold text-white">{user.name}</h3>
            <p className="text-sm text-gray-400">{user.email}</p>
            <div className="mt-1 inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-green-500/10 text-green-400 border border-green-500/20">
              Active Member
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 border-b border-white/5 divide-x divide-white/5">
            <div className="p-4 text-center hover:bg-white/5 transition cursor-pointer">
                <div className="text-xl font-bold text-white">12</div>
                <div className="text-[10px] text-gray-500 uppercase font-bold tracking-wider">Watched</div>
            </div>
            <div className="p-4 text-center hover:bg-white/5 transition cursor-pointer">
                <div className="text-xl font-bold text-white">5</div>
                <div className="text-[10px] text-gray-500 uppercase font-bold tracking-wider">Liked</div>
            </div>
            <div className="p-4 text-center hover:bg-white/5 transition cursor-pointer">
                <div className="text-xl font-bold text-white">0</div>
                <div className="text-[10px] text-gray-500 uppercase font-bold tracking-wider">Lists</div>
            </div>
        </div>

        {/* Menu Links */}
        <div>
          <button className="w-full px-6 py-4 flex items-center justify-between text-gray-300 hover:bg-white/5 hover:text-white transition group border-b border-white/5">
            <div className="flex items-center gap-3">
              <Settings size={18} />
              <span className="text-sm font-medium">Account Settings</span>
            </div>
            <ChevronRight size={16} className="opacity-0 group-hover:opacity-100 transition text-gray-500" />
          </button>
          <button className="w-full px-6 py-4 flex items-center justify-between text-gray-300 hover:bg-white/5 hover:text-white transition group border-b border-white/5">
            <div className="flex items-center gap-3">
              <div className="w-4 h-4 rounded border border-gray-500 flex items-center justify-center text-[10px] font-bold">?</div>
              <span className="text-sm font-medium">Help & Support</span>
            </div>
            <ChevronRight size={16} className="opacity-0 group-hover:opacity-100 transition text-gray-500" />
          </button>
          <button 
            onClick={() => {
                onLogout();
                onClose();
            }}
            className="w-full px-6 py-4 flex items-center justify-between text-red-400 hover:bg-red-500/10 transition group"
          >
            <div className="flex items-center gap-3">
              <LogOut size={18} />
              <span className="text-sm font-medium">Sign Out</span>
            </div>
          </button>
        </div>

        <div className="bg-black/40 p-4 text-center">
          <p className="text-[10px] text-gray-600">Member since {new Date().getFullYear()}</p>
        </div>

      </div>
    </div>
  );
};

export default UserProfile;