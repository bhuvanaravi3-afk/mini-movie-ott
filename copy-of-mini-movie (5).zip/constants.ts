import { Movie, Category } from "./types";

// Helper to generate mock movies
const generateMockMovies = (seed: string, count: number, genre: string): Movie[] => {
  return Array.from({ length: count }).map((_, i) => ({
    id: `${seed}-${i}`,
    title: `${genre}: Episode ${i + 1}`,
    description: `Episode ${i + 1} of 12. A viral ${genre.toLowerCase()} mini-series moment that explodes with drama in under two minutes.`,
    // Use portrait dimensions for seed
    thumbnailUrl: `https://picsum.photos/seed/${seed}${i}vert/300/450`, 
    backdropUrl: `https://picsum.photos/seed/${seed}${i}back/1280/720`, 
    matchScore: Math.floor(Math.random() * 20) + 80,
    year: 2024,
    ageRating: Math.random() > 0.5 ? "16+" : "13+",
    // Strict duration limit: 1 to 2 minutes
    duration: `${Math.floor(Math.random() * 2) + 1}m`,
    genre: [genre, "Mini-Series"],
    isOriginal: true
  }));
};

export const FEATURED_MOVIE: Movie = {
  id: "hero-1",
  title: "Vertical Horizon: Ep 1",
  description: "The pilot episode of the season. The world has turned 90 degrees. In this groundbreaking vertical exclusive, a climber attempts the impossible spire.",
  thumbnailUrl: "https://picsum.photos/seed/verticalhero/300/500",
  backdropUrl: "https://picsum.photos/seed/verticalhero/1920/1080",
  matchScore: 99,
  year: 2025,
  ageRating: "16+",
  duration: "2m",
  genre: ["Thriller", "Vertical Exclusive"],
  isOriginal: true
};

export const INITIAL_CATEGORIES: Category[] = [
  {
    id: "trending",
    title: "Trending Season 1",
    movies: generateMockMovies("trend", 12, "Viral")
  },
  {
    id: "drama",
    title: "Love & Betrayal (12 Episodes)",
    movies: generateMockMovies("drama", 12, "Drama")
  },
  {
    id: "comedy",
    title: "Office Pranks (12 Episodes)",
    movies: generateMockMovies("comedy", 12, "Comedy")
  },
  {
    id: "thriller",
    title: "2-Min Nightmares",
    movies: generateMockMovies("thrill", 12, "Suspense")
  }
];