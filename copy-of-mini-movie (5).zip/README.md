# Mini Movie - Vertical OTT Platform

The ultimate destination for premium vertical short-form content.

## 🚀 Deployment Guide (Vercel)

### Part 1: GitHub
1. Create a new repository on GitHub.
2. Upload all files from this project.
3. Commit changes.

### Part 2: Vercel Hosting
1. Connect your GitHub to [Vercel](https://vercel.com).
2. Import the project.
3. **Environment Variables**: Add `API_KEY` with your Gemini API Key.
4. Deploy. You will receive a URL like `https://mini-movie-example.vercel.app`.

---

## 🛍️ Integrating with Shopify

To show this OTT platform inside your Shopify store:

1.  **Go to Shopify Admin** -> **Online Store** -> **Pages**.
2.  Click **Add Page**.
3.  Set the title (e.g., "Watch Movies").
4.  In the Content editor, click the **Show HTML** button (`<>`).
5.  Paste the following code (replace `YOUR_VERCEL_URL` with your actual Vercel link):

```html
<div style="position: relative; width: 100%; height: 90vh; overflow: hidden; border-radius: 12px; border: 1px solid #333;">
  <iframe 
    src="YOUR_VERCEL_URL" 
    style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; border: none;"
    allow="autoplay; fullscreen; encrypted-media"
  ></iframe>
</div>
```

6.  **Save** the page.
7.  Go to **Navigation** -> **Main Menu** and add a link to this new page.

---

## ✨ Features
- **TikTok-Style UI**: Vertical-first playback optimized for mobile.
- **Nebula AI**: Smart episode recommendations using Gemini 3.
- **Admin Dashboard**: Upload episodes directly in the browser (persisted locally).
- **Responsive Design**: Works on Desktop, Tablet, and Mobile.