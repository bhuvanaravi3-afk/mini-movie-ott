export interface Movie {
  id: string;
  title: string;
  description: string;
  thumbnailUrl: string; // Poster/Vertical
  backdropUrl: string; // Wide
  videoUrl?: string; // Optional real video URL
  matchScore: number; // % match
  year: number;
  ageRating: string;
  duration: string;
  genre: string[];
  isOriginal?: boolean;
}

export interface Category {
  id: string;
  title: string;
  movies: Movie[];
}

export enum ViewState {
  HOME = 'HOME',
  PLAYER = 'PLAYER',
  SEARCH = 'SEARCH'
}

export interface User {
  id: string;
  name: string;
  email: string;
}