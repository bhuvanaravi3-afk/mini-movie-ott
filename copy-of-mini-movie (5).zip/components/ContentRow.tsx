import React, { useRef, useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Movie } from '../types';
import MovieCard from './MovieCard';

interface ContentRowProps {
  title: string;
  movies: Movie[];
  onMovieClick: (movie: Movie) => void;
  isGenerated?: boolean;
  id?: string;
}

const ContentRow: React.FC<ContentRowProps> = ({ title, movies, onMovieClick, isGenerated, id }) => {
  const rowRef = useRef<HTMLDivElement>(null);
  const [isMoved, setIsMoved] = useState(false);

  const handleClick = (direction: 'left' | 'right') => {
    setIsMoved(true);
    if (rowRef.current) {
      const { scrollLeft, clientWidth } = rowRef.current;
      const scrollTo = direction === 'left' 
        ? scrollLeft - clientWidth 
        : scrollLeft + clientWidth;
      
      rowRef.current.scrollTo({ left: scrollTo, behavior: 'smooth' });
    }
  };

  return (
    <div id={id} className="mb-8 space-y-2 px-4 md:px-12 scroll-mt-24">
      <h2 className={`text-lg md:text-2xl font-semibold transition hover:text-white cursor-pointer ${isGenerated ? 'text-brand-purple bg-clip-text text-transparent bg-gradient-to-r from-brand-purple to-blue-400 inline-block' : 'text-gray-200'}`}>
        {title} {isGenerated && "✨"}
      </h2>
      
      <div className="group relative md:-ml-2">
        <ChevronLeft 
          className={`absolute top-0 bottom-0 left-2 z-40 m-auto h-9 w-9 cursor-pointer opacity-0 transition hover:scale-125 group-hover:opacity-100 ${!isMoved && 'hidden'}`} 
          onClick={() => handleClick('left')} 
        />
        
        <div 
          ref={rowRef}
          className="flex items-center space-x-2 md:space-x-4 overflow-x-scroll scrollbar-hide md:p-2 scroll-smooth no-scrollbar"
        >
          {movies.map((movie) => (
            <MovieCard key={movie.id} movie={movie} onClick={onMovieClick} />
          ))}
        </div>

        <ChevronRight 
          className="absolute top-0 bottom-0 right-2 z-40 m-auto h-9 w-9 cursor-pointer opacity-0 transition hover:scale-125 group-hover:opacity-100" 
          onClick={() => handleClick('right')} 
        />
      </div>
    </div>
  );
};

export default ContentRow;