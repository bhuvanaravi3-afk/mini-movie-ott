
import React, { useEffect, useState, useRef } from 'react';
import { ArrowLeft, Play, Pause, Share2, Heart, MessageCircle, X, Copy, Check, Link as LinkIcon, Eye, Volume2, VolumeX, Maximize, Minimize, SkipForward, RotateCcw, RotateCw, Loader2 } from 'lucide-react';
import { Movie } from '../types';

interface VideoPlayerProps {
  movie: Movie;
  onBack: () => void;
  onNext: () => void;
}

const VideoPlayer: React.FC<VideoPlayerProps> = ({ movie, onBack, onNext }) => {
  const [isPlaying, setIsPlaying] = useState(true);
  const [isEnded, setIsEnded] = useState(false);
  const [progress, setProgress] = useState(0);
  const [isShareOpen, setIsShareOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [isBuffering, setIsBuffering] = useState(true);
  
  const [volume, setVolume] = useState(80);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  
  const [viewCount, setViewCount] = useState(0);
  const [hasViewed, setHasViewed] = useState(false);

  useEffect(() => {
    setProgress(0);
    setIsPlaying(true);
    setIsEnded(false);
    setHasViewed(false);
    setIsBuffering(true);
  }, [movie.id]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (isShareOpen) return;
      
      switch (e.code) {
        case 'Space':
          e.preventDefault();
          togglePlay();
          break;
        case 'ArrowRight':
          e.preventDefault();
          skipForward();
          break;
        case 'ArrowLeft':
          e.preventDefault();
          skipBackward();
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isPlaying, isEnded, isShareOpen]);

  useEffect(() => {
    const seed = movie.title.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    const randomViews = 10000 + (seed * 123) % 900000;
    setViewCount(randomViews);
  }, [movie.id]);

  useEffect(() => {
    let viewTimer: ReturnType<typeof setTimeout>;
    if (isPlaying && !hasViewed && !isEnded) {
      viewTimer = setTimeout(() => {
        setViewCount(prev => prev + 1);
        setHasViewed(true);
      }, 5000);
    }
    return () => clearTimeout(viewTimer);
  }, [isPlaying, hasViewed, isEnded]);

  useEffect(() => {
    const videoEl = videoRef.current;
    if (!videoEl) return;

    const handleWaiting = () => setIsBuffering(true);
    const handlePlaying = () => setIsBuffering(false);
    const handleCanPlay = () => setIsBuffering(false);
    const handleTimeUpdate = () => {
      if (videoEl.duration > 0) {
        setProgress((videoEl.currentTime / videoEl.duration) * 100);
      }
    };

    videoEl.addEventListener('waiting', handleWaiting);
    videoEl.addEventListener('playing', handlePlaying);
    videoEl.addEventListener('canplay', handleCanPlay);
    videoEl.addEventListener('timeupdate', handleTimeUpdate);

    if (isPlaying && !isEnded) {
      videoEl.play().catch(() => {});
    } else {
      videoEl.pause();
    }

    videoEl.volume = volume / 100;
    videoEl.muted = isMuted;

    return () => {
      videoEl.removeEventListener('waiting', handleWaiting);
      videoEl.removeEventListener('playing', handlePlaying);
      videoEl.removeEventListener('canplay', handleCanPlay);
      videoEl.removeEventListener('timeupdate', handleTimeUpdate);
    };
  }, [isPlaying, isEnded, movie.id, volume, isMuted]);

  const togglePlay = () => {
    if (isEnded) {
      setIsEnded(false);
      setProgress(0);
      setIsPlaying(true);
      if (videoRef.current) {
        videoRef.current.currentTime = 0;
        videoRef.current.play();
      }
    } else {
      setIsPlaying(!isPlaying);
    }
  };

  const skipForward = () => {
    if (videoRef.current) {
      videoRef.current.currentTime = Math.min(videoRef.current.duration, videoRef.current.currentTime + 10);
    }
  };

  const skipBackward = () => {
    if (videoRef.current) {
      videoRef.current.currentTime = Math.max(0, videoRef.current.currentTime - 10);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    if (videoRef.current) {
      const time = (val / 100) * videoRef.current.duration;
      videoRef.current.currentTime = time;
      setProgress(val);
    }
  };

  const toggleFullscreen = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!document.fullscreenElement && containerRef.current) {
      containerRef.current.requestFullscreen();
    } else if (document.exitFullscreen) {
      document.exitFullscreen();
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="fixed inset-0 z-[60] bg-black flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0 opacity-30">
         <img src={movie.thumbnailUrl} className="w-full h-full object-cover blur-3xl scale-125" alt="background" />
      </div>

      {!isFullscreen && (
        <button onClick={onBack} className="absolute top-6 left-6 z-50 p-3 bg-black/50 hover:bg-black/70 rounded-full text-white transition">
            <ArrowLeft size={24} />
        </button>
      )}
      
      <div ref={containerRef} className={`relative bg-black overflow-hidden shadow-2xl border-white/10 flex flex-col group/player ${isFullscreen ? 'w-full h-full border-none' : 'w-full md:w-[450px] h-full md:h-[90vh] md:rounded-2xl border'}`}>
         
         <div className="relative flex-1 bg-gray-900 flex items-center justify-center overflow-hidden">
             <video 
               ref={videoRef}
               src={movie.videoUrl || "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"}
               className={`absolute inset-0 w-full h-full ${isFullscreen ? 'object-contain' : 'object-cover'}`}
               playsInline
               onEnded={() => { setIsPlaying(false); setIsEnded(true); }}
               onClick={togglePlay}
             />

             {isBuffering && !isEnded && (
               <div className="absolute inset-0 flex items-center justify-center bg-black/20 z-20">
                 <Loader2 className="w-12 h-12 text-brand-accent animate-spin" />
               </div>
             )}

             <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black/60 pointer-events-none"></div>
             
             {!isPlaying && !isEnded && !isBuffering && (
                 <div className="absolute z-20 bg-black/50 p-6 rounded-full backdrop-blur-sm cursor-pointer" onClick={togglePlay}>
                     <Play fill="white" size={48} className="text-white" />
                 </div>
             )}

             {isEnded && (
                <div className="absolute inset-0 z-40 bg-black/70 backdrop-blur-sm flex flex-col items-center justify-center p-8 animate-fade-in">
                    <h3 className="text-white text-xl font-bold mb-4">Up Next</h3>
                    <button onClick={onNext} className="bg-brand-accent hover:bg-red-600 text-white px-8 py-4 rounded-full font-bold text-lg flex items-center gap-3 transition transform hover:scale-105 mb-4">
                        <SkipForward fill="currentColor" size={24} /> Play Next Video
                    </button>
                    <button onClick={togglePlay} className="text-gray-300 hover:text-white text-sm font-medium flex items-center gap-2">
                        <RotateCcw size={14} /> Replay
                    </button>
                </div>
             )}

             {!isEnded && (
                 <div className="absolute right-4 bottom-32 flex flex-col items-center gap-6 z-30">
                    <div className="flex flex-col items-center gap-1">
                        <div className={`p-3 backdrop-blur-md rounded-full transition cursor-pointer ${hasViewed ? 'bg-brand-accent/20 text-brand-accent' : 'bg-white/10 text-white hover:bg-white/20'}`}>
                            <Eye size={24} />
                        </div>
                        <span className="text-xs font-bold">{hasViewed ? (viewCount / 1000).toFixed(1) + 'K' : '...'}</span>
                    </div>
                    <div className="p-3 bg-white/10 backdrop-blur-md rounded-full hover:bg-white/20 transition cursor-pointer">
                        <Heart size={24} />
                    </div>
                    <div className="p-3 bg-white/10 backdrop-blur-md rounded-full hover:bg-white/20 transition cursor-pointer">
                        <Share2 size={24} onClick={() => setIsShareOpen(true)} />
                    </div>
                 </div>
             )}

             <div className="absolute bottom-0 left-0 w-full p-4 pb-6 bg-gradient-to-t from-black/95 via-black/60 to-transparent z-40">
                 <div className="mb-4 max-w-[85%]">
                     <h3 className="text-xl font-bold mb-1">{movie.title}</h3>
                     <p className="text-sm text-gray-300 line-clamp-1">{movie.description}</p>
                 </div>
                 
                 <div className="flex items-center justify-center gap-8 mb-4">
                    <button onClick={skipBackward} className="text-white/80 hover:text-white transition p-2 bg-white/10 rounded-full">
                      <RotateCcw size={20} />
                    </button>
                    <button onClick={togglePlay} className="text-white transition p-3 bg-brand-accent rounded-full scale-110">
                      {isPlaying ? <Pause size={24} fill="currentColor" /> : <Play size={24} fill="currentColor" />}
                    </button>
                    <button onClick={skipForward} className="text-white/80 hover:text-white transition p-2 bg-white/10 rounded-full">
                      <RotateCw size={20} />
                    </button>
                 </div>

                 <div className="relative group/scrub">
                   <input 
                      type="range" 
                      min="0" 
                      max="100" 
                      step="0.1"
                      value={progress} 
                      onChange={handleSeek}
                      className="w-full h-1.5 bg-gray-600 rounded-lg appearance-none cursor-pointer accent-brand-accent mb-2"
                   />
                 </div>
                 
                 <div className="flex justify-between text-[10px] text-gray-400 font-medium px-1">
                     <span>{videoRef.current ? formatTime(videoRef.current.currentTime) : '0:00'}</span>
                     <span>{movie.duration}</span>
                 </div>

                 <div className="flex items-center justify-between mt-4">
                    <div className="flex items-center gap-3">
                        <button onClick={() => setIsMuted(!isMuted)} className="text-white/80 hover:text-white transition">
                            {isMuted || volume === 0 ? <VolumeX size={18} /> : <Volume2 size={18} />}
                        </button>
                        <input type="range" min="0" max="100" value={isMuted ? 0 : volume} onChange={(e) => setVolume(parseInt(e.target.value))} className="w-16 h-1 bg-gray-700 rounded-lg appearance-none cursor-pointer accent-white" />
                    </div>
                    <button onClick={toggleFullscreen} className="text-white/80 hover:text-white transition">
                         {isFullscreen ? <Minimize size={18} /> : <Maximize size={18} />}
                    </button>
                 </div>
             </div>
         </div>
      </div>
    </div>
  );
};

export default VideoPlayer;
