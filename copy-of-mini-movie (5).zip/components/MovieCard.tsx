import React from 'react';
import { Play, Plus, ThumbsUp } from 'lucide-react';
import { Movie } from '../types';

interface MovieCardProps {
  movie: Movie;
  onClick: (movie: Movie) => void;
}

const MovieCard: React.FC<MovieCardProps> = ({ movie, onClick }) => {
  return (
    <div 
      className="group relative h-64 md:h-80 min-w-[114px] md:min-w-[160px] cursor-pointer transition-all duration-300 ease-in-out"
      onClick={() => onClick(movie)}
    >
      {/* Vertical Poster */}
      <img 
        src={movie.thumbnailUrl} 
        alt={movie.title} 
        className="w-full h-full object-cover rounded-lg shadow-lg group-hover:scale-105 transition-transform duration-300"
      />
      
      {/* Overlay Gradient */}
      <div className="absolute inset-0 rounded-lg bg-gradient-to-t from-black/90 via-transparent to-transparent opacity-60 group-hover:opacity-40 transition-opacity"></div>

      {/* Card Info */}
      <div className="absolute bottom-0 left-0 w-full p-3 opacity-100 transition-all">
        {movie.isOriginal && (
           <div className="text-[10px] font-bold text-brand-accent uppercase mb-1 tracking-wider">Mini Original</div>
        )}
        <p className="text-sm font-bold text-white leading-tight mb-1 shadow-black drop-shadow-md">{movie.title}</p>
        <div className="flex items-center gap-2 text-[10px] text-gray-300">
            <span className="text-green-400 font-bold">{movie.matchScore}%</span>
            <span>•</span>
            <span>{movie.duration}</span>
            <span className="border border-white/30 px-1 rounded">Free</span>
        </div>
      </div>

      {/* Hover Actions Overlay */}
      <div className="absolute inset-0 bg-black/60 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-4 backdrop-blur-[2px]">
         <button className="w-12 h-12 rounded-full bg-brand-accent flex items-center justify-center hover:scale-110 transition shadow-lg shadow-brand-accent/40">
            <Play fill="white" className="ml-1 w-5 h-5" />
         </button>
         <div className="flex gap-3">
            <button className="p-2 rounded-full bg-white/20 hover:bg-white/40 transition">
                <Plus size={16} />
            </button>
            <button className="p-2 rounded-full bg-white/20 hover:bg-white/40 transition">
                <ThumbsUp size={16} />
            </button>
         </div>
      </div>
    </div>
  );
};

export default MovieCard;