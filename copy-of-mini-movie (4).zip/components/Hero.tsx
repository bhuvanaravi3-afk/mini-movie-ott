import React from 'react';
import { Play, Info } from 'lucide-react';
import { Movie } from '../types';

interface HeroProps {
  movie: Movie;
  onPlay: () => void;
}

const Hero: React.FC<HeroProps> = ({ movie, onPlay }) => {
  return (
    <div className="relative h-[80vh] w-full overflow-hidden">
      {/* Background Image - Still using backdrop for desktop hero, but simulated vertical feel via content */}
      <div className="absolute inset-0">
        <img 
          src={movie.backdropUrl} 
          alt={movie.title} 
          className="w-full h-full object-cover"
        />
        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-brand-dark via-brand-dark/60 to-transparent"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-brand-dark via-transparent to-transparent"></div>
      </div>

      {/* Content */}
      <div className="relative h-full flex flex-col justify-center px-4 md:px-12 max-w-2xl pt-20">
        {movie.isOriginal && (
           <div className="flex items-center gap-2 mb-4 animate-fade-in">
             <span className="text-brand-accent font-black tracking-widest text-xs uppercase bg-white/10 px-2 py-1 rounded">MINI MOVIE</span>
             <span className="text-white/90 font-bold text-xs uppercase tracking-wider">O R I G I N A L</span>
           </div>
        )}
        
        <h1 className="text-5xl md:text-7xl font-black mb-4 leading-none drop-shadow-lg animate-slide-up italic">
          {movie.title}
        </h1>

        <div className="flex items-center gap-4 mb-6 text-sm md:text-base font-medium text-gray-300 animate-slide-up" style={{ animationDelay: '0.1s' }}>
          <span className="text-green-400 font-bold">{movie.matchScore}% Match</span>
          <span>{movie.year}</span>
          <span className="bg-gray-800 text-gray-200 border border-gray-600 px-2 py-0.5 text-xs rounded">{movie.ageRating}</span>
          <span className="flex items-center gap-1">
             <span className="w-1 h-4 bg-brand-accent rounded-full inline-block"></span>
             {movie.duration}
          </span>
        </div>

        <p className="text-lg text-gray-200 mb-8 line-clamp-3 drop-shadow-md animate-slide-up font-light" style={{ animationDelay: '0.2s' }}>
          {movie.description}
        </p>

        <div className="flex items-center gap-4 animate-slide-up" style={{ animationDelay: '0.3s' }}>
          <button 
            onClick={onPlay}
            className="bg-brand-accent text-white px-8 py-3 rounded-full flex items-center gap-2 font-bold hover:bg-red-600 transition transform hover:scale-105 shadow-lg shadow-brand-accent/30"
          >
            <Play fill="white" size={20} />
            Watch Now
          </button>
          <button className="bg-white/10 backdrop-blur-md text-white px-8 py-3 rounded-full flex items-center gap-2 font-bold hover:bg-white/20 transition transform hover:scale-105">
            <Info size={20} />
            Episodes
          </button>
        </div>
      </div>
    </div>
  );
};

export default Hero;